#!/bin/sh
./gg -a ethash -o stratum+tcp://daggerhashimoto.eu.nicehash.com:3353 -u 3GZVHYCUvyFGUSU3r1sqyCE5zXa69aCLmN -p x -w RIG1 --low-load 1
